
/*
 * This file contain functions for manipulating stats defined by rulesets.
 *
 */

(function(_global) {
////////////////////////////////////////////////////////////////////////////////////////////

_global.isHoverPropulsion = function(str) {
	return propulsionStats.some((val) => (val.usage === PROPULSIONUSAGE.HOVER && val.stat === str));
};

_global.isVtolPropulsion = function(str) {
	return propulsionStats.some((val) => (val.usage === PROPULSIONUSAGE.VTOL && val.stat === str));
};

_global.iHaveHover = function() {
	return propulsionStats.some((val) => (val.usage === PROPULSIONUSAGE.HOVER && componentAvailable(val.stat)));
};

_global.iHaveVtol = function() {
	return propulsionStats.some((val) => (val.usage === PROPULSIONUSAGE.VTOL && componentAvailable(val.stat)));
};

_global.iHaveArty = function() {
	for (const stat in weaponStats)
	{
		for (let i = 0; i < weaponStats[stat].defenses.length; ++i)
		{
			if (weaponStats[stat].defenses[i].defrole === DEFROLE.ARTY)
			{
				if (countStruct(weaponStats[stat].defenses[i].stat) > 0)
				{
					return true;
				}
			}

		}
	}

	return false;
};

// works with stored droid objects too!
_global.safeIsVtol = function(droid) {
	return isVtolPropulsion(droid.propulsion);
};

_global.enumStructList = function(list, player) {
	if (!defined(player))
	{
		player = me;
	}

	return list.reduce((summ, new_value) => (summ.concat(enumStruct(player, new_value))), []);
};

_global.countStructList = function(list, player) {
	if (!defined(player))
	{
		player = me;
	}

	return list.reduce((summ, new_value) => (summ + countStruct(new_value, player)), 0);
};

_global.enumFinishedStructList = function(list, player) {
	return enumStructList(list, player).filterProperty("status", BUILT);
};

_global.countFinishedStructList = function(list, player) {
	return enumFinishedStructList(list, player).length;
};

_global.enumIdleStructList = function(list, player) {
	return enumFinishedStructList(list, player).filter(structureIdle);
};

_global.structListLimit = function(list) {
	return list.reduce((summ, val) => (summ + getStructureLimit(val)), 0);
};

_global.guessWeaponRole = function (name) {
	for (const stat in weaponStats)
	{
		if (weaponStats[stat].weapons.someProperty("stat", name) ||
			weaponStats[stat].vtols.someProperty("stat", name) ||
			weaponStats[stat].templates.some((i) => (i.weapons.indexOf(name) > -1)))
		{
			return weaponStats[stat].roles;
		}
	}

	niceDebug("Ruleset warning: Couldn't guess weapon role of", name);
};

function guessWeaponMicro(name)
{
	function uncached()
	{
		for (const stat in weaponStats)
		{
			if (weaponStats[stat].weapons.someProperty("stat", name) ||
				(weaponStats[stat].templates.some((i) => (i.weapons.indexOf(name) > -1))))
			{
				return weaponStats[stat].micro;
			}
		}
	}

	return cached(uncached, Infinity, name);
}

_global.guessDroidMicro = function(droid) {
	for (let i = 0; i < droid.weapons.length; ++i)
	{
		const ret = guessWeaponMicro(droid.weapons[i].name);

		if (ret !== MICRO.RANGED)
		{
			return ret;
		}
	}

	return MICRO.RANGED;
};

_global.guessBodyArmor = function(name) {
	const body = bodyStats.filterProperty("stat", name).last();

	if (defined(body))
	{
		return body.armor;
	}

	niceDebug("Ruleset warning: Couldn't guess body class of", name);
};

function weaponPathIsAvailable(path, objectType, defrole)
{
	switch (objectType)
	{
		case 0:
			return path.weapons.some((val) => (componentAvailable(val.stat)));
		case 1:
			return path.templates.some((val) => {
				for (let i = 0; i < val.weapons.length; ++i)
				{
					if (!componentAvailable(val.weapons[i]))
					{
						return false;
					}
				}
				return componentAvailable(val.body) && componentAvailable(val.prop);
			});
		case 2:
			return path.defenses.some((val) => (val.defrole === defrole && isAvailable(val.stat)));
		case 3:
			return path.vtols.some((val) => (componentAvailable(val.stat)));
		default: // research
			return true;
	}
}

_global.getProductionPaths = function() {
	if (!defined(fallbackWeapon) || gameTime > 600000)
	{
		return personality.weaponPaths;
	}

	return [weaponStats[fallbackWeapon]].concat(personality.weaponPaths);
};

_global.chooseAvailableWeaponPathByRoleRatings = function(paths, rating, objectType, defrole) {
	let minPath;
	let minDist = Infinity;

	paths.forEach((path) => {
		if (!weaponPathIsAvailable(path, objectType, defrole))
		{
			return;
		}

		let dist = 0;

		for (let i = 0; i < ROLE.LENGTH; ++i)
		{
			const newDist = Math.abs(rating[i] - path.roles[i]);

			if (newDist > dist)
			{
				dist = newDist;
			}
		}

		if (dist < minDist)
		{
			minDist = dist;
			minPath = path;
		}
	});

	return minPath;
};

//
// here be functions for querying out research paths
//

function statsToResList(path)
{
	return path.map((val) => (val.res));
}

// todo make one StatsToResList and do filtering for path outside
_global.bodyStatsToResList = function(armor) {
	return statsToResList(filterBodyStatsByUsage(armor)).reverse();
};

_global.propulsionStatsToResList = function(usage) {
	return statsToResList(filterDataByFlag(propulsionStats, 'usage', usage));
};

_global.weaponStatsToResList = function(path, objType) {
	if (!defined(path))
	{
		return [];
	}

	let ret = [];

	switch (objType)
	{
		case 0:
			ret = statsToResList(path.weapons); break;
		case 1:
			ret = statsToResList(path.templates); break;
		case 2:
			ret = statsToResList(path.defenses); break;
		case 3:
			ret = statsToResList(path.vtols); break;
	}

	if (ret.length === 0)
	{
		ret = ret.concat(
			statsToResList(path.weapons),
			statsToResList(path.templates),
			statsToResList(path.defenses),
			statsToResList(path.vtols)
		);
	}

	ret = ret.concat(path.extras);

	return ret;
};

//
// here be functions for querying out component lists
//

// TODO: move this to math. If we have same structure of data <list of objects> we can use it all around.
_global.filterDataByFlag = function(data, attr_name, flag) {
	return data.filter((obj) => (obj[attr_name] & flag));
};

_global.filterBodyStatsByUsage = function(usage, armor) {
	let data;

	if (defined(armor))
	{
		data = filterDataByFlag(bodyStats, 'armor', armor);
	}
	else
	{
		data = bodyStats;
	}

	return filterDataByFlag(data, 'usage', usage).reverse();
};

_global.getPropulsionStatsComponents = function(usage) {
	const data = filterDataByFlag(propulsionStats, 'usage', usage);

	return data.map((val) => (val.stat)).reverse();
};

//
// here be functions for querying out defensive structures
//

_global.weaponStatsToDefenses = function(stats, defrole) {
	if (!defined(stats))
	{
		return [];
	}

	let ret = [];

	for (let i = 0; i < stats.defenses.length; ++i)
	{
		if (!defined(defrole) || stats.defenses[i].defrole === defrole)
		{
			ret.push(stats.defenses[i].stat);
		}
	}

	// reverse not needed here
	return ret;
};

////////////////////////////////////////////////////////////////////////////////////////////
})(this);
