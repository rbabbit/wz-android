receiveAllEvents(true);

// Include global variables
include("SurvivalMod/ENEMY.js");
include("SurvivalMod/ENTRANCES.js");
include("SurvivalMod/TEMPLATES.js");
include("SurvivalMod/LATEST_RESEARCH.js");

// Include rest
include("SurvivalMod/reticule.js");
include("SurvivalMod/audio.js");
include("SurvivalMod/minimap.js");
include("SurvivalMod/power.js");
include("SurvivalMod/research.js");
include("SurvivalMod/texture.js");
include("SurvivalMod/weather.js");
include("SurvivalMod/gameOver.js");
include("SurvivalMod/base.js");
include("SurvivalMod/limits.js");
include("SurvivalMod/enableStructure.js");
include("SurvivalMod/experience.js");
include("SurvivalMod/vtol.js");
include("SurvivalMod/spawn.js");
