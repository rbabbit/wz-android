/**
 * An enemy player may be required to start the game, so Tower Defense Mod
 * provides a dummy AI called "Scavengers".
 * This function removes the dummy AI from the map.
 */
function removeScavengerAI()
{
	hackNetOff();
	for (let player = 0; player < maxPlayers; player++)
	{
		if (playerData[player].isAI)
		{
			enumStruct(player).forEach(s => removeObject(s));
			enumDroid(player).forEach(s => removeObject(s));
		}
	}
	hackNetOn();
}

/**
 * @returns {number} The player number to use for the scavenger AI
 */
function getScavAI()
{
	if (scavengers !== 0)
	{
		return scavengerPlayer; // "true" scavs
	}

	for (let player = 0; player < maxPlayers; player++)
	{
		if (playerData[player].isAI)
		{
			return player; // "false" scavs
		}
	}

	// HACK WARNING TODO
	// No dedicated enemy player has been provided. The mod can still spawn and
	// control scavengers, but saving/loading will not work because the units
	// disappear.
	return scavengerPlayer; // "hack" scavs
}

/**
 * @param {number} player
 * @param {number} power - amount of power increase
 */
function addPower(player, power)
{
	hackNetOff();
	setPower(playerPower(player) + power, player);
	hackNetOn();
}

function disableVTOL()
{
	for (let player = 0; player < maxPlayers; player++)
	{
		setStructureLimits("A0VTolFactory1", 0, player);
	}
}

/**
 * We want to increase the rank of the units in each round linearly and
 * consistently. To do this, generate an array where the index is the round
 * number, and the element at the index is the rank number. e.g. the rank of the
 * units in round 3/12 can be obtained by calculateRanks(12)[3].
 *
 * @returns {number[]}
 */
function calculateRanks(totalNumRounds)
{
	const result = new Array(totalNumRounds + 1).fill(0);
	if (totalNumRounds < 2)
	{
		return result;
	}

	const totalNumRanks = Stats.Brain["Z NULL BRAIN"].RankThresholds.length;
	const step = Math.max(1, Math.floor((totalNumRanks - 1) / (totalNumRounds - 1)));

	for (let i = 1; i <= totalNumRounds; i++)
	{
		result[i] = Math.floor((i - 1) / Math.ceil((totalNumRounds - 1) / (totalNumRanks - 1))) * step;
	}

	return result;
}

/**
 * Pick a random element from an array, or null.
 *
 * @param {any[]} arr
 * @returns {any|null}
 */
function pick(arr)
{
	if (!arr || arr.length == 0)
	{
		return null;
	}
	return arr[syncRandom(arr.length)];
}

// The initial research time, in seconds.
const initialResearchTimeS = (() =>
{
	let startTime = 1;
	const techLevel = getMultiTechLevel();
	if (baseType == CAMP_BASE)
	{
		startTime = timeBaseTech;
	}
	if (baseType == CAMP_WALLS)
	{
		startTime = timeAdvancedBaseTech;
	}
	if (techLevel == 2)
	{
		startTime = timeT2;
	}
	if (techLevel == 3)
	{
		startTime = timeT3;
	}
	if (techLevel == 4)
	{
		startTime = Infinity;
	}
	return startTime;
})();

/**
 * @returns {number} the current research time, in milliseconds.
 */
function currentResearchTime()
{
	return (initialResearchTimeS * 1000) + gameTime;
}

/**
 * Give all research that is theoretically currently available to player.
 *
 * @param {number} player - player number
 * @param {number} time - time in milliseconds
 */
function giveResearch(player, time)
{
	hackNetOff();
	for (const [tech, seconds] of Object.entries(minimumResearchTime))
	{
		const milliseconds = seconds * 1000;
		if (milliseconds <= time)
		{
			completeResearch(tech, player);
		}
	}
	hackNetOn();
}

// The theoretical minimum research time for each technology, as of November 2025.
const minimumResearchTime = {
	"R-Sys-Spade1Mk1": 0,
	"R-Vehicle-Body01": 0,
	"R-Vehicle-Prop-Wheels": 0,
	"R-Wpn-MG1Mk1": 5,
	"R-Wpn-MG-Damage01": 48,
	"R-Defense-Tower01": 48,
	"R-Sys-Sensor-Turret01": 65,
	"R-Sys-Engineering01": 86,
	"R-Defense-TankTrap01": 108,
	"R-Wpn-Flamer01Mk1": 129,
	"R-Defense-HardcreteWall": 129,
	"R-Sys-Sensor-Tower01": 129,
	"R-Sys-MobileRepairTurret01": 129,
	"R-Wpn-MG-Damage02": 133,
	"R-Vehicle-Engine01": 172,
	"R-Defense-Pillbox05": 172,
	"R-Defense-Pillbox01": 172,
	"R-Wpn-Flamer-Damage01": 172,
	"R-Defense-HardcreteGate": 172,
	"R-Vehicle-Prop-Halftracks": 172,
	"R-Sys-Sensor-Tower02": 172,
	"R-Wpn-Cannon1Mk1": 176,
	"R-Struc-Factory-Cyborg": 215,
	"R-Defense-WallUpgrade01": 215,
	"R-Struc-CommandRelay": 215,
	"R-Defense-Pillbox04": 219,
	"R-Defense-WallTower02": 219,
	"R-Wpn-MG2Mk1": 219,
	"R-Struc-PowerModuleMk1": 258,
	"R-Wpn-Flamer-Damage02": 258,
	"R-Comp-CommandTurret01": 258,
	"R-Wpn-Rocket05-MiniPod": 258,
	"R-Wpn-Cannon-Damage01": 262,
	"R-Struc-Research-Module": 300,
	"R-Defense-Tower06": 300,
	"R-Wpn-Flamer-ROF01": 315,
	"R-Vehicle-Engine02": 329,
	"R-Wpn-Rocket-Damage01": 329,
	"R-Struc-Materials01": 358,
	"R-Struc-Research-Upgrade01": 358,
	"R-Defense-WallUpgrade02": 358,
	"R-Wpn-MG-Damage03": 360,
	"R-Struc-Factory-Module": 381,
	"R-Wpn-Mortar01Lt": 383,
	"R-Wpn-Flamer-Damage03": 385,
	"R-Wpn-Cannon-Damage02": 385,
	"R-Wpn-MG3Mk1": 407,
	"R-Defense-MortarPit": 407,
	"R-Wpn-Rocket-Damage02": 427,
	"R-Vehicle-Body05": 427,
	"R-Cyborg-Metals01": 427,
	"R-Defense-WallTower01": 430,
	"R-Vehicle-Metals01": 450,
	"R-Struc-Research-Upgrade02": 450,
	"R-Wpn-Mortar-Damage01": 452,
	"R-Struc-RepairFacility": 470,
	"R-Struc-Factory-Upgrade01": 470,
	"R-Sys-MobileRepairTurretHvy": 470,
	"R-Defense-WallUpgrade03": 489,
	"R-Vehicle-Body04": 489,
	"R-Wpn-Rocket02-MRL": 508,
	"R-Cyborg-Metals02": 508,
	"R-Wpn-Cannon2Mk1": 508,
	"R-Vehicle-Prop-Hover": 508,
	"R-Vehicle-Engine03": 508,
	"R-Wpn-Cannon-Damage03": 512,
	"R-Wpn-Cannon-Accuracy01": 512,
	"R-Defense-MRL": 534,
	"R-Defense-WallTower03": 534,
	"R-Struc-RprFac-Upgrade01": 547,
	"R-Wpn-Rocket-Damage03": 547,
	"R-Wpn-Rocket-ROF01": 547,
	"R-Wpn-Rocket-Accuracy01": 547,
	"R-Struc-Research-Upgrade03": 567,
	"R-Vehicle-Metals02": 567,
	"R-Wpn-MG-Damage04": 568,
	"R-Wpn-Mortar-Damage02": 568,
	"R-Wpn-Mortar-Acc01": 568,
	"R-Wpn-MG-ROF01": 583,
	"R-Cyborg-Metals03": 617,
	"R-Wpn-Flamer-Damage04": 619,
	"R-Vehicle-Prop-Tracks": 633,
	"R-Vehicle-Body11": 633,
	"R-Vehicle-Body08": 633,
	"R-Wpn-Rocket01-LtAT": 650,
	"R-Wpn-Cannon4AMk1": 653,
	"R-Defense-WallTower06": 675,
	"R-Defense-Pillbox06": 675,
	"R-Defense-Emplacement-HPVcannon": 678,
	"R-Defense-WallTower-HPVcannon": 678,
	"R-Wpn-Rocket-ROF02": 683,
	"R-Struc-VTOLFactory": 683,
	"R-Wpn-Cannon-Damage04": 686,
	"R-Struc-Research-Upgrade04": 700,
	"R-Wpn-Mortar-Acc02": 702,
	"R-Cyborg-Armor-Heat01": 715,
	"R-Vehicle-Metals03": 715,
	"R-Wpn-MG-ROF02": 715,
	"R-Vehicle-Body12": 729,
	"R-Sys-Sensor-Upgrade01": 744,
	"R-Wpn-Mortar3": 760,
	"R-Wpn-MG-Damage05": 760,
	"R-Wpn-Mortar-Damage03": 760,
	"R-Wpn-Mortar02Hvy": 760,
	"R-Cyborg-Transport": 773,
	"R-Wpn-Rocket-Damage04": 773,
	"R-Vehicle-Body02": 773,
	"R-Wpn-Rocket03-HvAT": 773,
	"R-Defense-RotMor": 784,
	"R-Defense-HvyMor": 784,
	"R-Wpn-Cannon-ROF01": 786,
	"R-Sys-RadarDetector01": 793,
	"R-Wpn-AAGun03": 802,
	"R-Wpn-Sunburst": 802,
	"R-Wpn-Mortar-ROF01": 804,
	"R-Wpn-AAGun01": 805,
	"R-Wpn-Flame2": 805,
	"R-Struc-Factory-Upgrade04": 807,
	"R-Sys-Engineering02": 817,
	"R-Wpn-Cannon-Accuracy02": 817,
	"R-Defense-Sunburst": 827,
	"R-Defense-AASite-QuadMg1": 827,
	"R-Defense-HvyFlamer": 829,
	"R-Defense-WallTower-DoubleAAgun": 830,
	"R-Defense-AASite-QuadBof": 830,
	"R-Vehicle-Armor-Heat01": 832,
	"R-Vehicle-Prop-VTOL": 832,
	"R-Cyborg-Armor-Heat02": 832,
	"R-Cyborg-Metals04": 837,
	"R-Struc-Research-Upgrade05": 846,
	"R-Struc-Power-Upgrade01": 846,
	"R-Wpn-Mortar-Acc03": 848,
	"R-Wpn-Flamer-Damage05": 853,
	"R-Wpn-MG4": 859,
	"R-Sys-CBSensor-Turret01": 859,
	"R-Wpn-Cannon-Damage05": 862,
	"R-SuperTransport": 868,
	"R-Vehicle-Engine04": 868,
	"R-Sys-CBSensor-Tower01": 883,
	"R-Defense-Wall-RotMg": 883,
	"R-Defense-RotMG": 883,
	"R-Wpn-Rocket-Accuracy02": 886,
	"R-Vehicle-Metals04": 894,
	"R-Wpn-Cannon5": 897,
	"R-Struc-VTOLPad": 912,
	"R-Wpn-Rocket-Damage05": 912,
	"R-Wpn-Rocket-ROF03": 912,
	"R-Wpn-Mortar-Incendiary": 914,
	"R-Defense-Wall-VulcanCan": 921,
	"R-Sys-Sensor-Upgrade02": 925,
	"R-Cyborg-Hvywpn-Mcannon": 925,
	"R-Wpn-MG-Damage06": 939,
	"R-Wpn-Mortar-ROF02": 939,
	"R-Defense-MortarPit-Incendiary": 940,
	"R-Wpn-Flamer-ROF02": 940,
	"R-Wpn-Cannon-ROF02": 942,
	"R-Struc-RprFac-Upgrade04": 942,
	"R-Defense-WallUpgrade04": 951,
	"R-Wpn-Bomb01": 953,
	"R-Cyborg-Armor-Heat03": 964,
	"R-Wpn-Mortar-Damage04": 969,
	"R-Struc-Power-Upgrade01b": 977,
	"R-Vehicle-Armor-Heat02": 986,
	"R-Wpn-MG-ROF03": 990,
	"R-Vehicle-Body06": 999,
	"R-Cyborg-Metals05": 1003,
	"R-Cyborg-Hvywpn-Acannon": 1012,
	"R-Cyborg-Hvywpn-HPV": 1012,
	"R-Wpn-Rocket06-IDF": 1016,
	"R-Wpn-RocketSlow-Accuracy01": 1016,
	"R-Struc-VTOLPad-Upgrade01": 1016,
	"R-Struc-Research-Upgrade06": 1020,
	"R-Wpn-Rocket02-MRLHvy": 1040,
	"R-Wpn-Cannon-Damage06": 1042,
	"R-Wpn-Cannon3Mk1": 1050,
	"R-Vehicle-Engine05": 1060,
	"R-Sys-VTOLStrike-Turret01": 1063,
	"R-Wpn-Rocket-Damage06": 1063,
	"R-Defense-MRLHvy": 1063,
	"R-Wpn-Mortar-ROF03": 1071,
	"R-Defense-WallTower04": 1073,
	"R-Struc-Materials02": 1075,
	"R-Sys-VTOLStrike-Tower01": 1087,
	"R-Wpn-Flamer-Damage06": 1089,
	"R-Vehicle-Metals05": 1095,
	"R-Struc-Power-Upgrade01c": 1099,
	"R-Wpn-Bomb03": 1101,
	"R-Wpn-Bomb-Damage01": 1101,
	"R-Wpn-Flamer-ROF03": 1105,
	"R-Wpn-Cannon-ROF03": 1107,
	"R-Defense-IDFRocket": 1111,
	"R-Defense-WallUpgrade05": 1114,
	"R-Wpn-MG-Damage07": 1120,
	"R-Wpn-Rocket07-Tank-Killer": 1134,
	"R-Struc-VTOLPad-Upgrade02": 1134,
	"R-Wpn-Mortar-Damage05": 1157,
	"R-Wpn-RocketSlow-Accuracy02": 1158,
	"R-Defense-WallTower-HvyA-Trocket": 1158,
	"R-Defense-HvyA-Trocket": 1158,
	"R-Wpn-Cannon6TwinAslt": 1159,
	"R-Wpn-MG5": 1162,
	"R-Vehicle-Armor-Heat03": 1165,
	"R-Defense-Cannon6": 1182,
	"R-Defense-WallTower-TwinAGun": 1185,
	"R-Cyborg-Metals06": 1193,
	"R-Wpn-HowitzerMk1": 1209,
	"R-Cyborg-Hvywpn-TK": 1212,
	"R-Struc-Research-Upgrade07": 1216,
	"R-Wpn-Rocket-Damage07": 1227,
	"R-Sys-VTOLCBS-Turret01": 1227,
	"R-Wpn-Cannon-Damage07": 1229,
	"R-Wpn-AAGun04": 1231,
	"R-Wpn-Mortar-ROF04": 1234,
	"R-Wpn-Bomb02": 1240,
	"R-Sys-VTOLCBS-Tower01": 1250,
	"R-Wpn-PlasmaCannon": 1252,
	"R-Defense-WallTower-QuadRotAA": 1254,
	"R-Defense-AASite-QuadRotMg": 1254,
	"R-Comp-CommandTurret02": 1261,
	"R-Vehicle-Engine06": 1270,
	"R-Defense-Super-Cannon": 1274,
	"R-Defense-PlasmaCannon": 1275,
	"R-Wpn-Bomb04": 1275,
	"R-Wpn-Bomb-Damage02": 1275,
	"R-Struc-VTOLPad-Upgrade03": 1284,
	"R-Defense-Howitzer": 1296,
	"R-Vehicle-Body09": 1299,
	"R-Defense-WallUpgrade06": 1302,
	"R-Wpn-MG-Damage08": 1303,
	"R-Vehicle-Metals06": 1313,
	"R-Wpn-Howitzer-Damage01": 1317,
	"R-Wpn-Mortar-Damage06": 1330,
	"R-Cyborg-Armor-Heat04": 1338,
	"R-Wpn-Howitzer-Accuracy01": 1339,
	"R-Wpn-Plasmite-Flamer": 1345,
	"R-Sys-Sensor-Upgrade03": 1345,
	"R-Defense-PlasmiteFlamer": 1368,
	"R-Struc-Power-Upgrade02": 1377,
	"R-Wpn-Howitzer-Incendiary": 1389,
	"R-Wpn-Howitzer03-Rot": 1389,
	"R-Wpn-AAGun02": 1395,
	"R-Wpn-Rocket-Damage08": 1399,
	"R-Cyborg-Metals07": 1402,
	"R-Wpn-Cannon-ROF04": 1408,
	"R-Defense-WallTower-DoubleAAgun02": 1418,
	"R-Defense-AASite-QuadBof02": 1418,
	"R-Wpn-Cannon-Damage08": 1422,
	"R-Struc-Research-Upgrade08": 1431,
	"R-Wpn-Howitzer-Damage02": 1458,
	"R-Struc-VTOLPad-Upgrade04": 1460,
	"R-Wpn-Laser01": 1470,
	"R-Defense-Howitzer-Incendiary": 1471,
	"R-Wpn-Bomb-Damage03": 1472,
	"R-Defense-RotHow": 1474,
	"R-Sys-Sensor-WS": 1480,
	"R-Wpn-MG-Damage09": 1481,
	"R-Wpn-RailGun01": 1482,
	"R-Defense-PrisLas": 1493,
	"R-Wpn-Howitzer-Accuracy02": 1497,
	"R-Sys-Sensor-WSTower": 1503,
	"R-Vehicle-Armor-Heat04": 1503,
	"R-Defense-GuardTower-Rail1": 1505,
	"R-Wpn-Missile2A-T": 1506,
	"R-Cyborg-Armor-Heat05": 1509,
	"R-Defense-WallTower-A-Tmiss": 1529,
	"R-Defense-GuardTower-ATMiss": 1529,
	"R-Vehicle-Metals07": 1546,
	"R-Sys-SpyTurret": 1549,
	"R-Wpn-Flamer-Damage07": 1568,
	"R-Sys-SpyTower": 1572,
	"R-Struc-Power-Upgrade03": 1578,
	"R-Wpn-Rocket-Damage09": 1578,
	"R-Sys-Engineering03": 1588,
	"R-Cyborg-Hvywpn-A-T": 1588,
	"R-Defense-Super-Rocket": 1598,
	"R-Wpn-Bomb06": 1603,
	"R-Wpn-Cannon-ROF05": 1606,
	"R-Wpn-Cannon-Damage09": 1619,
	"R-Wpn-Howitzer-Damage03": 1622,
	"R-Cyborg-Metals08": 1627,
	"R-Struc-VTOLPad-Upgrade05": 1657,
	"R-Struc-Research-Upgrade09": 1660,
	"R-Vehicle-Body03": 1663,
	"R-Sys-Autorepair-General": 1666,
	"R-Wpn-EMPCannon": 1666,
	"R-Wpn-MG-Damage10": 1673,
	"R-Wpn-Bomb05": 1678,
	"R-Wpn-Howitzer-Accuracy03": 1679,
	"R-Defense-EMPCannon": 1689,
	"R-Wpn-HvyHowitzer": 1691,
	"R-Wpn-Energy-Damage01": 1703,
	"R-Wpn-Energy-Accuracy01": 1703,
	"R-Cyborg-Armor-Heat06": 1703,
	"R-Vehicle-Armor-Heat05": 1712,
	"R-Wpn-Rail-Damage01": 1713,
	"R-Wpn-Missile-ROF01": 1736,
	"R-Wpn-Missile-LtSAM": 1736,
	"R-Struc-RprFac-Upgrade06": 1745,
	"R-Vehicle-Engine07": 1751,
	"R-Defense-SamSite1": 1759,
	"R-Defense-WallTower-SamSite": 1759,
	"R-Struc-Power-Upgrade03a": 1766,
	"R-Defense-WallUpgrade07": 1775,
	"R-Defense-HvyHowitzer": 1782,
	"R-Vehicle-Metals08": 1791,
	"R-Wpn-Flamer-Damage08": 1806,
	"R-Wpn-Cannon-ROF06": 1823,
	"R-Struc-Factory-Upgrade07": 1824,
	"R-Cyborg-Metals09": 1866,
	"R-Struc-VTOLPad-Upgrade06": 1869,
	"R-Wpn-MortarEMP": 1878,
	"R-Defense-EMPMortar": 1901,
	"R-Wpn-Howitzer-Damage04": 1909,
	"R-Wpn-Howitzer-ROF01": 1909,
	"R-Cyborg-Armor-Heat07": 1915,
	"R-Wpn-Laser02": 1921,
	"R-Wpn-Energy-ROF01": 1921,
	"R-Wpn-Rail-Accuracy01": 1932,
	"R-Sys-Resistance-Circuits": 1933,
	"R-Vehicle-Armor-Heat06": 1939,
	"R-Defense-PulseLas": 1944,
	"R-Defense-WallTower-PulseLas": 1944,
	"R-Wpn-Missile-Damage01": 1954,
	"R-Wpn-MdArtMissile": 1954,
	"R-Struc-Materials03": 1957,
	"R-Defense-MdArtMissile": 1977,
	"R-Defense-WallUpgrade08": 1988,
	"R-Cyborg-Hvywpn-PulseLsr": 1997,
	"R-Vehicle-Body07": 2009,
	"R-Sys-Sensor-UpLink": 2030,
	"R-Vehicle-Metals09": 2057,
	"R-Wpn-Flamer-Damage09": 2066,
	"R-Struc-Factory-Upgrade09": 2115,
	"R-Wpn-Energy-Damage02": 2139,
	"R-Wpn-Rail-Damage02": 2150,
	"R-Wpn-Rail-ROF01": 2150,
	"R-Cyborg-Armor-Heat08": 2157,
	"R-Wpn-Missile-Accuracy01": 2172,
	"R-Wpn-Missile-ROF02": 2172,
	"R-Vehicle-Armor-Heat07": 2197,
	"R-Defense-WallUpgrade09": 2230,
	"R-Vehicle-Engine08": 2236,
	"R-Wpn-HeavyPlasmaLauncher": 2242,
	"R-Wpn-Howitzer-ROF02": 2346,
	"R-Wpn-Howitzer-Damage05": 2346,
	"R-Wpn-Energy-ROF02": 2357,
	"R-Wpn-AALaser": 2357,
	"R-Defense-AA-Laser": 2380,
	"R-Wpn-Missile-Damage02": 2391,
	"R-Cyborg-Armor-Heat09": 2430,
	"R-Wpn-HvyLaser": 2466,
	"R-Vehicle-Armor-Heat08": 2485,
	"R-Defense-HeavyLas": 2489,
	"R-Vehicle-Body10": 2494,
	"R-Defense-WallUpgrade10": 2503,
	"R-Wpn-RailGun02": 2586,
	"R-Wpn-Rail-ROF02": 2586,
	"R-Defense-WallTower-Rail2": 2609,
	"R-Wpn-Missile-Accuracy02": 2609,
	"R-Defense-Rail2": 2609,
	"R-Cyborg-Hvywpn-RailGunner": 2670,
	"R-Defense-HeavyPlasmaLauncher": 2678,
	"R-Vehicle-Engine09": 2751,
	"R-Wpn-Energy-Damage03": 2794,
	"R-Vehicle-Armor-Heat09": 2803,
	"R-Wpn-Missile-ROF03": 2827,
	"R-Wpn-HvArtMissile": 2827,
	"R-Defense-WallUpgrade11": 2836,
	"R-Wpn-LasSat": 2888,
	"R-Wpn-Howitzer-ROF03": 3000,
	"R-Wpn-Howitzer-Damage06": 3000,
	"R-Wpn-Energy-ROF03": 3012,
	"R-Wpn-Missile-Damage03": 3045,
	"R-Wpn-ParticleGun": 3121,
	"R-Defense-ParticleGun": 3144,
	"R-Vehicle-Body13": 3188,
	"R-Defense-WallUpgrade12": 3200,
	"R-Wpn-Rail-Damage03": 3241,
	"R-Wpn-Rail-ROF03": 3241,
	"R-Wpn-RailGun03": 3241,
	"R-Defense-Rail3": 3263,
	"R-Defense-WallTower-Rail3": 3263,
	"R-Defense-HvyArtMissile": 3263,
	"R-Wpn-Missile-HvSAM": 3482,
	"R-Defense-WallTower-SamHvy": 3504,
	"R-Defense-SamSite2": 3504,
	"R-Defense-Super-Missile": 3585,
	"R-Vehicle-Body14": 3842,
	"R-Wpn-Howitzer-ROF04": 3858,
	"R-Defense-MassDriver": 3998,
};
